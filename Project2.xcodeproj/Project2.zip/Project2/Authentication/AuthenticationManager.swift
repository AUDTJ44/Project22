//
//  AuthenticationManager.swift
//  Project2
//
//  Created by 이명서 on 2023/09/27.
//

import Foundation
import FirebaseAuth

struct AuthDataResultModel{
    let uid: String
    let email: String? //optional String
    let photoUrl: String?
}

final class AuthenticationManager{
    
    //Singletons -> create a single Global instance of authentication manager
    static let shared = AuthenticationManager()
    private init() { } //this is the only instance of this class in our whole app - 'private'
    
    //async version bc we're using swift concurrency
    func createUser(email: String, password: String) async throws{
        let authDataResult = try await Auth.auth().createUser(withEmail: email, password: password)
        _ = AuthDataResultModel(
            uid: authDataResult.user.uid,
            email: authDataResult.user.email,
            photoUrl: authDataResult.user.photoURL?.absoluteString)
    }
}

