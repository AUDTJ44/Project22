//
//  AuthenticationView.swift
//  Project2
//
//  Created by 이명서 on 2023/09/27.
//

import SwiftUI

    struct AuthenticationView: View {
        
        var body: some View {
            VStack{
                
                NavigationLink{
                    LoginView()
                }label:{
                    Text("Login")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(height:55)
                        .frame(maxWidth: .infinity)
                        .background(Color(red: 0.848, green: 0.119, blue: 0.232))
                        .cornerRadius(10)
                }
                Spacer()
            }
            .padding()
            .navigationTitle("Log In")
        }
    }
    
    #Preview {
        NavigationStack{
            AuthenticationView()
        }
    }


