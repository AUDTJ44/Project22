//
//  LoginView.swift
//  Project2
//
//  Created by 이명서 on 2023/09/27.
//

import SwiftUI
import Firebase

@MainActor
//'final'bc implies we're not gonna inherit from this class in other class
//performance benefit
final class LoginViewModel: ObservableObject{
    
    @Published var email = ""
    @Published var password = ""
    
    func logIn(){
        guard !email.isEmpty, !password.isEmpty else {
            print("No email or password found.")
            return //VALIDATION - not just print out please enter vaild email and password
        }
        
        Task{//see concurrency playlist
            do{
                let returnedUserData: () = try await AuthenticationManager.shared.createUser(email: email, password: password)
                print("Success")
                print(returnedUserData)
            } catch {
                print("Error: \(error)")
            }
        }
        
    }
}

//
struct LoginView: View {
    
    @StateObject private var viewModel = LoginViewModel()
    @State private var email = ""
    @State private var password = ""
    @State private var userIsLoggedIn = false
    
    
    var body: some View {
        if userIsLoggedIn{
            HomeView()
        }else{
            content
        }
    }
    
    var content: some View{
        ZStack{
            VStack{
                TextField("Email", text: $viewModel.email)
                    .padding()
                    .background(Color.gray.opacity(0.4))
                    .cornerRadius(10)
                
                SecureField("Password", text: $viewModel.password)
                    .padding()
                    .background(Color.gray.opacity(0.4))
                    .cornerRadius(10)
                
                Button{
                    login()
                } label:{
                    Text("Login")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(height:55)
                        .frame(maxWidth: .infinity)
                        .background(Color(red: 0.848, green: 0.119, blue: 0.232))
                        .cornerRadius(10)
                }
                Spacer()
            }
            .padding()
            .navigationTitle("Log In With Email")
            
            //if we login, this will turn to TRUE
            onAppear {
                Auth.auth().addStateDidChangeListener {auth,user in
                    if user != nil {
                        userIsLoggedIn.toggle()
                    }
                }
            }
        }
    }
    
    func login() {
        Auth.auth().signIn(withEmail: email, password: password) {result, error in
            if error != nil{
                print("error")
            }
        }
    }
}

#Preview {
    NavigationStack{
        LoginView()
    }
}
