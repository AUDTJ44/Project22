//
//  Project2App.swift
//  Project2
//
//  Created by 이명서 on 2023/09/27.
//

import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseCore
import FirebaseFirestore

//struct AuthenticationView: View {
    //@StateObject var dataManager = DataManager()

    @main
    struct Project2App: App {
        
        @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
        
        init(){
            FirebaseApp.configure()
        }
        var body: some Scene {
            WindowGroup {
                AuthenticationView()
                    //.environmentObject(dataManager)
            }
        }
    }
    class AppDelegate: NSObject, UIApplicationDelegate {
        func application(_ application: UIApplication,
                         didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
            FirebaseApp.configure()
            
            return true
        }
    }
