//
//  InventoryViewManager.swift
//  Project2
//
//  Created by 이명서 on 2023/09/30.
//

import FirebaseCore
import FirebaseFirestore

class InventoryViewManager: ObservableObject {
    @Published var cakes = [Cake]()
    
    private var db = Firestore.firestore()
    
    func fetchCakes() {
        db.collection("cakes").addSnapshotListener {(querySnapshot, error) in
            guard let documents = querySnapshot?.documents else {
                print("NO documents")
                return
            }
            
            self.cakes = documents.map { (queryDocumentSnapshot) -> Cake in
                let data = queryDocumentSnapshot.data()
                let id = data["id"] as? String ?? ""
                let name = data["name"] as? String ?? ""
                let image = data["image"] as? String ?? ""
                let stock = Int(data["stock"] as? String ?? "")
                return Cake(id: id, name: name, image: image, stock: stock!)
            }
        }
    }
}














