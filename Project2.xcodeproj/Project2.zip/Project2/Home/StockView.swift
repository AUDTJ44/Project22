//
//  StockView.swift
//  Project2
//
//  Created by 이명서 on 2023/09/30.
//

import SwiftUI

struct StockView: Identifiable {
    var id: ObjectIdentifier
    
    var name: String
    var image: String
    var stock: Int
}
