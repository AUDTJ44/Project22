//
//  InventoryManager.swift
//  Project2
//
//  Created by 이명서 on 2023/09/30.
//

import Foundation

struct Cakes: Identifiable {
    var id: String = UUID().uuidString
    var name: String
    var image: String
    var stock: Int
}
