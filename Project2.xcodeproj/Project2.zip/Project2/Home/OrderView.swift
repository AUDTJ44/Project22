//
//  OrderView.swift
//  Project2
//
//  Created by 이명서 on 2023/09/27.
//


import SwiftUI
import Firebase
import FirebaseFirestore

struct OrderView: View {
    @State private var cakes = [Cake]()

    var body: some View {
        NavigationView {
            List(cakes) { cake in
                HStack {
                    Text(cake.name)
                    Spacer()
                    Text("\(cake.stock)")
                }
            }
            .navigationBarTitle("Order")
            .onAppear(perform: loadData)
        }
    }

    private func loadData() {
        fetchCakes { cakes in
            self.cakes = cakes.filter { $0.stock < 3 }
        }
    }

    func fetchCakes(completion: @escaping ([Cake]) -> Void) {
        let db = Firestore.firestore()
        db.collection("cakes").whereField("stock", isLessThan: 3).getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching cakes: \(error)")
                completion([])
                return
            }

            guard let querySnapshot = querySnapshot else {
                print("Error fetching cakes: querySnapshot is nil")
                completion([])
                return
            }

            let cakes = querySnapshot.documents.compactMap { document in try? document.data(with: Cake.self)
            }

            completion(cakes)
        }
    }
}

struct OrderView_Previews: PreviewProvider {
    static var previews: some View {
        OrderView()
    }
}
