//
//  OrderManager.swift
//  Project2
//
//  Created by 이명서 on 2023/09/30.
//

import Foundation
import Firebase
import FirebaseFirestore


func fetchCakes(completion: @escaping ([Cake]) -> Void) {
    let db = Firestore.firestore()
    db.collection("cakes").whereField("stock", isLessThan: 3).getDocuments { (querySnapshot, error) in
        if let error = error {
            print("Error fetching cakes: \(error)")
            completion([])
            return
        }

        guard let querySnapshot = querySnapshot else {
            print("Error fetching cakes: querySnapshot is nil")
            completion([])
            return
        }

        let cakes = querySnapshot.documents.compactMap { document in
            let result = Result { try document.data(as: Cake.self) }
            switch result {
            case .success(let cake):
                return cake
            case .failure(let error):
                print("Error decoding cake: \(error)")
                return nil
            }
        }

        completion(cakes)
    }
}
