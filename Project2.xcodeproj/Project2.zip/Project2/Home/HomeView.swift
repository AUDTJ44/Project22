//
//  HomeView.swift
//  Project2
//
//  Created by 이명서 on 2023/09/27.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack{
            NavigationLink{
                InventoryView()
            } label:{
                Text("Inventory")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(height:55)
                    .frame(maxWidth: .infinity)
                    .background(Color(red: 0.848, green: 0.119, blue: 0.232))
                    .cornerRadius(10)
            }
            NavigationLink{
                OrderView()
            } label:{
                Text("Order")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(height:55)
                    .frame(maxWidth: .infinity)
                    .background(Color(red: 0.848, green: 0.119, blue: 0.232))
                    .cornerRadius(10)
                    
            }
            Spacer()
       }
        .padding()
        .navigationTitle("Home")
    }
}
#Preview {
    NavigationStack{
        HomeView()
    }
}
