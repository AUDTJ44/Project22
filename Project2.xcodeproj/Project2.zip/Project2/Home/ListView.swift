//
//  ListView.swift
//  Project2
//
//  Created by 이명서 on 2023/09/30.
//

import SwiftUI

struct ListView: View {
    @EnvironmentObject var dataManager : Datamanager
    
    
    var body: some View {
        NavigationView{
            List(dataManager.cakes, name: \.name) { cake in
                Text(cake.image)
            }
            .navigationTitle("cakes")
            .navigationBarItems(trailing: Button(action:{
                //add
            }, label: {
                Image(systemName: "plus")
            }))
        }
    }
}

#Preview {
    ListView()
}
