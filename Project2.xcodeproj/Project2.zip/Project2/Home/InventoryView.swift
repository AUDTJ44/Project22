//
//  InventoryView.swift
//  Project2
//
//  Created by 이명서 on 2023/09/27.
//
import SwiftUI
import Firebase

struct Cake: Identifiable {
var id: ObjectIdentifier

    var name: String
    var image: String
    var stock: Int
}

struct InventoryView: View {
    
    @ObservedObject private var viewModel = InventoryViewManager()
    
    var body: some View {
        NavigationView {
            List(viewModel.cakes){ cake in
                VStack(alignment: .leading) {
                    Text(cake.name).font(.subheadline)
                    Text(cake.image).font(.subheadline)
                    
                }
            }.navigationBarTitle("Cakes")
            .onAppear() {
self.viewModel.fetchD$ata
            }
        }
    }
}
    #Preview {
        NavigationStack{
            InventoryView()
        }
    }
