//
//  StockManagerView.swift
//  Project2
//
//  Created by 이명서 on 2023/09/30.
//

import SwiftUI
import Firebase
import FirebaseFirestore

class Datamanager : ObservedObject<<#ObjectType: ObservableObject#>> {
    @Published var cakes: [Cake] = []
    
    init() {
        fetchCakes()
    }
    
    func fetchCakes() {
        cakes.removeAll()
        let db = Firestore.firestore()
        let ref = db.collection("cakes")
        ref.getDocument { snapshot, error in
            guard error == nil else{
                print("error")
                return
            }
            if let snapshot = snapshot {
                for document in snapshot.documents {
                    let data = document.data()
                    
                    let name = data["name"] as? String ?? ""
                    let image = data["image"] as? String ?? ""
                    let stock = Int(data["stock"] as? String ?? "")
                    
                    let cake = Cake(name:name, image:image, stock:stock!)
                    self.cakes.append(cake)
                }
            }
        }
    }
}
