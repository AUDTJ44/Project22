//
//  StockManager2.swift
//  Project2
//
//  Created by 이명서 on 2023/09/30.
//

import SwiftUI

struct StockManager2: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    StockManager2()
}
